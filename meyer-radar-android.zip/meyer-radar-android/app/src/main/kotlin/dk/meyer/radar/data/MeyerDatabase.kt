package dk.meyer.radar.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject

class MeyerDatabase private constructor(context: Context) : SQLiteOpenHelper(context.applicationContext, "meyer_radar.db", null, 1) {

    companion object {
        @Volatile private var instance: MeyerDatabase? = null

        fun get(context: Context): MeyerDatabase = instance ?: synchronized(this) {
            instance ?: MeyerDatabase(context).also { instance = it }
        }
    }

    override fun onCreate(database: SQLiteDatabase) {
        database.execSQL(
            """
            CREATE TABLE IF NOT EXISTS scan_log(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp INTEGER NOT NULL,
                source TEXT NOT NULL,
                json TEXT NOT NULL
            )
            """.trimIndent()
        )
        database.execSQL(
            """
            CREATE TABLE IF NOT EXISTS detections(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp INTEGER NOT NULL,
                source TEXT NOT NULL,
                rule_id TEXT NOT NULL,
                label TEXT NOT NULL,
                category TEXT NOT NULL,
                country TEXT NOT NULL,
                confidence TEXT NOT NULL,
                match_type TEXT NOT NULL,
                matched_field TEXT NOT NULL,
                matched_value TEXT NOT NULL,
                device_name TEXT NOT NULL,
                identifier TEXT NOT NULL,
                rssi INTEGER NOT NULL,
                json TEXT NOT NULL
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(database: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Version 1 is the initial schema.
    }

    @Synchronized
    fun insertScan(source: String, devices: JSONArray) {
        writableDatabase.insert(
            "scan_log",
            null,
            ContentValues().apply {
                put("timestamp", System.currentTimeMillis())
                put("source", source)
                put("json", devices.toString())
            }
        )
    }

    @Synchronized
    fun insertDetection(detection: Detection) {
        writableDatabase.insert(
            "detections",
            null,
            ContentValues().apply {
                put("timestamp", detection.timestamp)
                put("source", detection.source)
                put("rule_id", detection.ruleId)
                put("label", detection.label)
                put("category", detection.category)
                put("country", detection.country)
                put("confidence", detection.confidence)
                put("match_type", detection.matchType)
                put("matched_field", detection.matchedField)
                put("matched_value", detection.matchedValue)
                put("device_name", detection.deviceName)
                put("identifier", detection.identifier)
                put("rssi", detection.rssi)
                put("json", detection.toJson().toString())
            }
        )
    }

    @Synchronized
    fun timeline(limit: Int = 100): List<TimelineEntry> {
        val result = mutableListOf<TimelineEntry>()
        readableDatabase.rawQuery(
            "SELECT timestamp, source, json FROM scan_log ORDER BY id DESC LIMIT ?",
            arrayOf(limit.toString())
        ).use { cursor ->
            while (cursor.moveToNext()) {
                val timestamp = cursor.getLong(0)
                val source = cursor.getString(1)
                val json = cursor.getString(2)
                val devices = try {
                    JSONArray(json)
                } catch (exception: Exception) {
                    JSONArray()
                }
                result += TimelineEntry(
                    timestamp = timestamp,
                    scanType = source,
                    networkCount = devices.length(),
                    topThreat = topThreat(devices)
                )
            }
        }
        return result
    }

    @Synchronized
    fun debrief(scanLimit: Int = 200): DebriefReport {
        val scans = mutableListOf<Pair<String, JSONArray>>()
        readableDatabase.rawQuery(
            "SELECT source, json FROM scan_log ORDER BY id DESC LIMIT ?",
            arrayOf(scanLimit.toString())
        ).use { cursor ->
            while (cursor.moveToNext()) {
                val source = cursor.getString(0)
                val json = try {
                    JSONArray(cursor.getString(1))
                } catch (exception: Exception) {
                    JSONArray()
                }
                scans += source to json
            }
        }

        var wifiScans = 0
        var wifiCount = 0
        var scoreTotal = 0
        var scoreCount = 0
        var maxScore = 0
        val uniqueBssids = mutableSetOf<String>()
        val bands = mutableMapOf<String, Int>()
        val security = mutableMapOf<String, Int>()
        val openNetworks = mutableSetOf<String>()
        val highRisk = mutableSetOf<String>()

        for ((source, devices) in scans) {
            if (source == "wifi") wifiScans++
            for (index in 0 until devices.length()) {
                val item = devices.optJSONObject(index) ?: continue
                val name = item.optString("ssid").ifBlank { item.optString("name") }
                val identifier = item.optString("bssid").ifBlank { item.optString("address") }
                if (identifier.isNotBlank()) uniqueBssids += identifier
                val frequency = item.optInt("frequency")
                if (source == "wifi") {
                    wifiCount++
                    val band = if (frequency >= 5000) "5 GHz" else "2.4 GHz"
                    bands[band] = (bands[band] ?: 0) + 1
                    val securityLabel = securityLabel(item.optString("capabilities"))
                    security[securityLabel] = (security[securityLabel] ?: 0) + 1
                    if (securityLabel == "OPEN") openNetworks += name.ifBlank { identifier }
                }
                val score = item.optInt("risk_score")
                scoreTotal += score
                scoreCount++
                maxScore = maxOf(maxScore, score)
                if (score >= 6) highRisk += name.ifBlank { identifier }
            }
        }

        val averageScore = if (scoreCount == 0) 0.0 else scoreTotal.toDouble() / scoreCount
        val density = if (wifiScans == 0) 0.0 else wifiCount.toDouble() / wifiScans
        val threatLevel = when {
            maxScore >= 8 || averageScore >= 5.5 -> "CRITICAL"
            maxScore >= 6 || averageScore >= 4.0 -> "HIGH"
            maxScore >= 3 || averageScore >= 2.0 -> "ELEVATED"
            scoreCount == 0 -> "UNKNOWN"
            else -> "LOW"
        }

        val recommendations = mutableListOf<String>()
        if (openNetworks.isNotEmpty()) recommendations += "Review open networks before transmitting sensitive data."
        if (highRisk.isNotEmpty()) recommendations += "Investigate high-risk networks and confirm whether you recognize them."
        if (density > 15) recommendations += "Network density is high; use signal history to identify changes."
        recommendations += "A rule match is only a signal match; independently verify the device purpose."
        recommendations += "Radar position is relative and based on estimated distance, not compass direction."

        return DebriefReport(
            generatedAt = formatTime(System.currentTimeMillis()),
            totalScans = scans.size,
            uniqueBssids = uniqueBssids.size,
            averageDensity = density,
            threatLevel = threatLevel,
            bands = bands,
            security = security,
            openNetworks = openNetworks.take(20),
            highRisk = highRisk.take(20),
            recommendations = recommendations
        )
    }

    @Synchronized
    fun clearHistory() {
        writableDatabase.execSQL("DELETE FROM scan_log")
        writableDatabase.execSQL("DELETE FROM detections")
    }

    private fun topThreat(devices: JSONArray): String {
        var best = "-"
        var bestScore = -1
        for (index in 0 until devices.length()) {
            val item = devices.optJSONObject(index) ?: continue
            val score = item.optInt("risk_score", -1)
            if (score > bestScore) {
                bestScore = score
                val name = item.optString("ssid").ifBlank { item.optString("name") }
                val identifier = item.optString("bssid").ifBlank { item.optString("address") }
                best = name.ifBlank { identifier }.ifBlank { "unknown" }
            }
        }
        return best
    }
}
