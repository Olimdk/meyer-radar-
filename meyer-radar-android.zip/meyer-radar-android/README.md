# Meyer Radar

Native Android Wi-Fi/BLE scanner and relative-distance radar.

## Build

Open this directory in Android Studio and run the `app` configuration, or build with Gradle:

```bash
gradle :app:assembleDebug
```

Android Studio will create or update `local.properties` with the SDK path.

## Requirements

- Android 10 or newer
- Location permission
- Bluetooth and Nearby Devices permissions on Android 12+
- Wi-Fi and Bluetooth hardware are optional but required for their respective scans

## Radar limitation

The radar shows estimated distance and stable relative positions. RSSI does not provide a real compass bearing or exact physical coordinates.

## Rules

Default example rules are copied on first launch to:

```text
Android/data/dk.meyer.radar/files/detections/rules.json
```

On Android 11+, use the system Files app or `adb shell` to replace this file.
