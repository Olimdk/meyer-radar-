package dk.meyer.radar.data

import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.pow

const val MAX_EVENTS = 300
const val MAX_DETECTIONS = 300

data class DetectionRule(
    val ruleId: String,
    val label: String,
    val category: String,
    val country: String,
    val confidence: String,
    val matchType: String,
    val matchValue: String,
    val notes: String,
    val enabled: Boolean = true
)

data class Detection(
    val timestamp: Long,
    val source: String,
    val ruleId: String,
    val label: String,
    val category: String,
    val country: String,
    val confidence: String,
    val matchType: String,
    val matchedField: String,
    val matchedValue: String,
    val ruleMatchValue: String,
    val notes: String,
    val deviceName: String,
    val identifier: String,
    val rssi: Int
) {
    fun toJson(): JSONObject = JSONObject()
        .put("timestamp", timestamp)
        .put("source", source)
        .put("rule_id", ruleId)
        .put("label", label)
        .put("category", category)
        .put("country", country)
        .put("confidence", confidence)
        .put("match_type", matchType)
        .put("matched_field", matchedField)
        .put("matched_value", matchedValue)
        .put("rule_match_value", ruleMatchValue)
        .put("notes", notes)
        .put("device_name", deviceName)
        .put("identifier", identifier)
        .put("rssi", rssi)

    companion object {
        fun fromJson(json: JSONObject): Detection = Detection(
            timestamp = json.optLong("timestamp"),
            source = json.optString("source"),
            ruleId = json.optString("rule_id"),
            label = json.optString("label"),
            category = json.optString("category"),
            country = json.optString("country"),
            confidence = json.optString("confidence", "low"),
            matchType = json.optString("match_type"),
            matchedField = json.optString("matched_field"),
            matchedValue = json.optString("matched_value"),
            ruleMatchValue = json.optString("rule_match_value"),
            notes = json.optString("notes"),
            deviceName = json.optString("device_name"),
            identifier = json.optString("identifier"),
            rssi = json.optInt("rssi")
        )
    }
}

data class WifiDevice(
    val ssid: String,
    val bssid: String,
    val rssi: Int,
    val frequency: Int,
    val capabilities: String,
    val distanceMeters: Double,
    val riskScore: Int,
    val riskLabel: String,
    val timestamp: Long,
    val detections: List<Detection> = emptyList()
) {
    fun toJson(): JSONObject = JSONObject()
        .put("ssid", ssid)
        .put("bssid", bssid)
        .put("rssi", rssi)
        .put("frequency", frequency)
        .put("capabilities", capabilities)
        .put("distance_m", distanceMeters)
        .put("risk_score", riskScore)
        .put("risk_label", riskLabel)
        .put("timestamp", timestamp)
        .put("detections", JSONArray(detections.map { it.toJson() }))

    companion object {
        fun fromJson(json: JSONObject): WifiDevice {
            val detections = mutableListOf<Detection>()
            val array = json.optJSONArray("detections")
            if (array != null) {
                for (index in 0 until array.length()) {
                    detections += Detection.fromJson(array.getJSONObject(index))
                }
            }
            return WifiDevice(
                ssid = json.optString("ssid"),
                bssid = json.optString("bssid"),
                rssi = json.optInt("rssi"),
                frequency = json.optInt("frequency"),
                capabilities = json.optString("capabilities"),
                distanceMeters = json.optDouble("distance_m", 50.0),
                riskScore = json.optInt("risk_score"),
                riskLabel = json.optString("risk_label"),
                timestamp = json.optLong("timestamp"),
                detections = detections
            )
        }
    }
}

data class BleDevice(
    val name: String,
    val address: String,
    val rssi: Int,
    val serviceUuids: List<String>,
    val manufacturerData: Map<Int, String>,
    val vendor: String,
    val distanceMeters: Double,
    val riskScore: Int,
    val riskLabel: String,
    val timestamp: Long,
    val detections: List<Detection> = emptyList()
) {
    fun toJson(): JSONObject {
        val services = JSONArray()
        serviceUuids.forEach { services.put(it) }
        val manufacturer = JSONObject()
        manufacturerData.forEach { (key, value) -> manufacturer.put(key.toString(), value) }
        return JSONObject()
            .put("name", name)
            .put("address", address)
            .put("rssi", rssi)
            .put("service_uuids", services)
            .put("manufacturer_data", manufacturer)
            .put("vendor", vendor)
            .put("distance_m", distanceMeters)
            .put("risk_score", riskScore)
            .put("risk_label", riskLabel)
            .put("timestamp", timestamp)
            .put("detections", JSONArray(detections.map { it.toJson() }))
    }

    companion object {
        fun fromJson(json: JSONObject): BleDevice {
            val services = mutableListOf<String>()
            val serviceArray = json.optJSONArray("service_uuids")
            if (serviceArray != null) {
                for (index in 0 until serviceArray.length()) services += serviceArray.optString(index)
            }
            val manufacturer = mutableMapOf<Int, String>()
            val manufacturerJson = json.optJSONObject("manufacturer_data")
            if (manufacturerJson != null) {
                for (key in manufacturerJson.keys()) {
                    manufacturer[key.toIntOrNull() ?: continue] = manufacturerJson.optString(key)
                }
            }
            val detections = mutableListOf<Detection>()
            val detectionArray = json.optJSONArray("detections")
            if (detectionArray != null) {
                for (index in 0 until detectionArray.length()) {
                    detections += Detection.fromJson(detectionArray.getJSONObject(index))
                }
            }
            return BleDevice(
                name = json.optString("name"),
                address = json.optString("address"),
                rssi = json.optInt("rssi"),
                serviceUuids = services,
                manufacturerData = manufacturer,
                vendor = json.optString("vendor"),
                distanceMeters = json.optDouble("distance_m", 50.0),
                riskScore = json.optInt("risk_score"),
                riskLabel = json.optString("risk_label"),
                timestamp = json.optLong("timestamp"),
                detections = detections
            )
        }
    }
}

data class TimelineEntry(
    val timestamp: Long,
    val scanType: String,
    val networkCount: Int,
    val topThreat: String
)

data class DebriefReport(
    val generatedAt: String,
    val totalScans: Int,
    val uniqueBssids: Int,
    val averageDensity: Double,
    val threatLevel: String,
    val bands: Map<String, Int>,
    val security: Map<String, Int>,
    val openNetworks: List<String>,
    val highRisk: List<String>,
    val recommendations: List<String>
)

data class LogEvent(val timestamp: Long, val level: String, val message: String)

object RadarBus {
    val wifi = MutableStateFlow<List<WifiDevice>>(emptyList())
    val ble = MutableStateFlow<List<BleDevice>>(emptyList())
    val detections = MutableStateFlow<List<Detection>>(emptyList())
    val events = MutableStateFlow<List<LogEvent>>(emptyList())
    val scanning = MutableStateFlow(false)
    val safeMode = MutableStateFlow(true)
    val bleEnabled = MutableStateFlow(true)
    val backgroundRunning = MutableStateFlow(false)
    val rulesVersion = MutableStateFlow(0)

    fun log(level: String, message: String) {
        events.value = (listOf(LogEvent(System.currentTimeMillis(), level, message)) + events.value)
            .take(MAX_EVENTS)
    }

    fun addDetections(newDetections: List<Detection>) {
        if (newDetections.isEmpty()) return
        val merged = detections.value.associateBy { detectionKey(it) }.toMutableMap()
        newDetections.forEach { merged[detectionKey(it)] = it }
        detections.value = merged.values.sortedByDescending { it.timestamp }.take(MAX_DETECTIONS)
    }

    private fun detectionKey(detection: Detection): String = listOf(
        detection.source,
        detection.ruleId,
        detection.identifier,
        detection.matchedField,
        detection.matchedValue
    ).joinToString("|")
}

fun securityLabel(capabilities: String): String = when {
    capabilities.contains("WPA3", true) -> "WPA3"
    capabilities.contains("WPA2", true) || capabilities.contains("RSN", true) -> "WPA2"
    capabilities.contains("WPA", true) -> "WPA"
    capabilities.contains("WEP", true) -> "WEP"
    else -> "OPEN"
}

fun isOpenNetwork(capabilities: String): Boolean = securityLabel(capabilities) == "OPEN"

fun wifiRisk(capabilities: String, ssid: String, rssi: Int): Pair<Int, String> {
    var score = when (securityLabel(capabilities)) {
        "WPA3" -> 0
        "WPA2" -> 1
        "WPA" -> 2
        "WEP" -> 3
        else -> 5
    }
    val lowerSsid = ssid.lowercase(Locale.ROOT)
    score += when {
        listOf("hidden", "unknown", "setup", "config").any { lowerSsid.contains(it) } -> 3
        listOf("iot", "cam", "camera", "dvr", "sensor").any { lowerSsid.contains(it) } -> 2
        else -> 0
    }
    if (rssi > -50) score += 1
    if (securityLabel(capabilities) == "OPEN" && rssi > -60) score += 1
    score = score.coerceIn(0, 10)
    return score to when {
        score >= 8 -> "CRITICAL"
        score >= 6 -> "HIGH"
        score >= 3 -> "ELEVATED"
        score >= 1 -> "CHATTER"
        else -> "CLEAN"
    }
}

fun bleRisk(name: String, rssi: Int): Pair<Int, String> {
    val lowerName = name.lowercase(Locale.ROOT)
    var score = when {
        listOf("cam", "tracker", "tag", "sensor").any { lowerName.contains(it) } -> 4
        listOf("watch", "buds", "headphone", "band").any { lowerName.contains(it) } -> 1
        name.isBlank() -> 2
        else -> 0
    }
    if (rssi > -50) score += 2
    if (rssi > -65) score += 1
    score = score.coerceIn(0, 10)
    return score to when {
        score >= 7 -> "HIGH"
        score >= 4 -> "ELEVATED"
        score >= 2 -> "CHATTER"
        else -> "CLEAN"
    }
}

fun estimatedDistance(rssi: Int, frequencyMHz: Int = 2400, isBle: Boolean = false): Double {
    val txPower = when {
        isBle -> -59.0
        frequencyMHz >= 5000 -> -60.0
        else -> -50.0
    }
    val pathLossExponent = if (isBle) 2.5 else 2.7
    val distance = 10.0.pow((txPower - rssi) / (10.0 * pathLossExponent))
    return distance.coerceIn(0.5, 100.0)
}

fun maskMac(value: String): String {
    val parts = value.split(":")
    return if (parts.size == 6) ":**:**:**:**:" + parts.last() else ":**:**:**:**:**"
}

fun formatTime(timestamp: Long): String =
    SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(timestamp))
