package dk.meyer.radar

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dk.meyer.radar.data.MeyerDatabase
import dk.meyer.radar.data.RadarBus
import dk.meyer.radar.data.RuleEngine
import dk.meyer.radar.scan.RadarService
import dk.meyer.radar.scan.ScanController
import dk.meyer.radar.ui.BleScreen
import dk.meyer.radar.ui.DebriefScreen
import dk.meyer.radar.ui.DetectionsScreen
import dk.meyer.radar.ui.LogScreen
import dk.meyer.radar.ui.MeyerRadarTheme
import dk.meyer.radar.ui.RadarScreen
import dk.meyer.radar.ui.TimelineScreen
import dk.meyer.radar.ui.WifiScreen

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        RuleEngine(applicationContext).ensureDefaultRules()
        setContent {
            MeyerRadarTheme {
                MeyerRadarRoot()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MeyerRadarRoot() {
    val context = LocalContext.current.applicationContext
    val lifecycleOwner = LocalLifecycleOwner.current
    val controller = remember { ScanController(context) }
    val database = remember { MeyerDatabase.get(context) }

    var route by rememberSaveable { mutableStateOf("radar") }
    var permissionGranted by remember {
        mutableStateOf(ScanController.hasScanPermissions(context))
    }

    val wifi by RadarBus.wifi.collectAsStateWithLifecycle()
    val ble by RadarBus.ble.collectAsStateWithLifecycle()
    val detections by RadarBus.detections.collectAsStateWithLifecycle()
    val events by RadarBus.events.collectAsStateWithLifecycle()
    val scanning by RadarBus.scanning.collectAsStateWithLifecycle()
    val safeMode by RadarBus.safeMode.collectAsStateWithLifecycle()
    val bleEnabled by RadarBus.bleEnabled.collectAsStateWithLifecycle()
    val backgroundRunning by RadarBus.backgroundRunning.collectAsStateWithLifecycle()

    val requestedPermissions = remember {
        buildList {
            addAll(ScanController.requiredPermissions)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }.toTypedArray()
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        permissionGranted = ScanController.hasScanPermissions(context)
        if (permissionGranted) controller.start()
        else RadarBus.log("ERROR", "Required permissions were denied")
    }

    DisposableEffect(lifecycleOwner, permissionGranted) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> {
                    if (permissionGranted && !RadarService.isRunning) controller.start()
                }
                Lifecycle.Event.ON_STOP -> {
                    if (!RadarService.isRunning) controller.stop()
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            controller.stop()
        }
    }

    val timeline by produceState(initialValue = emptyList(), route) {
        if (route == "timeline") value = database.timeline(200)
    }

    val debrief by produceState<dk.meyer.radar.data.DebriefReport?>(
        initialValue = null,
        route
    ) {
        if (route == "debrief") value = database.debrief()
    }

    val toggleBackground = {
        if (RadarService.isRunning || backgroundRunning) {
            RadarService.stop(context)
            if (permissionGranted) controller.start()
        } else {
            permissionGranted = ScanController.hasScanPermissions(context)
            if (!permissionGranted) {
                permissionLauncher.launch(requestedPermissions)
            } else {
                controller.stop()
                try {
                    RadarService.start(context)
                } catch (exception: Exception) {
                    RadarBus.log("ERROR", "Background service failed: ${exception.message}")
                    controller.start()
                }
            }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Meyer Radar")
                        Text(
                            text = when {
                                backgroundRunning -> "Background scanning"
                                scanning -> "Scanning"
                                else -> "Idle"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = {
                    if (route == "timeline" || route == "debrief") {
                        IconButton(onClick = { route = "radar" }) {
                            Text("←")
                        }
                    }
                },
                actions = {
                    TextButton(onClick = { route = "timeline" }) { Text("Timeline") }
                    TextButton(onClick = { route = "debrief" }) { Text("Debrief") }
                    Switch(
                        checked = safeMode,
                        onCheckedChange = { RadarBus.safeMode.value = it }
                    )
                }
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = route == "radar",
                    onClick = { route = "radar" },
                    icon = { Text("R") },
                    label = { Text("Radar") }
                )
                NavigationBarItem(
                    selected = route == "wifi",
                    onClick = { route = "wifi" },
                    icon = { Text("W") },
                    label = { Text("Wi-Fi") }
                )
                NavigationBarItem(
                    selected = route == "ble",
                    onClick = { route = "ble" },
                    icon = { Text("B") },
                    label = { Text("BLE") }
                )
                NavigationBarItem(
                    selected = route == "detections",
                    onClick = { route = "detections" },
                    icon = { Text("!") },
                    label = { Text("Alerts") }
                )
                NavigationBarItem(
                    selected = route == "log",
                    onClick = { route = "log" },
                    icon = { Text("L") },
                    label = { Text("Log") }
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (!permissionGranted) {
                PermissionBanner(
                    onRequestPermission = {
                        permissionLauncher.launch(requestedPermissions)
                    }
                )
            } else {
                ControlStrip(
                    scanning = scanning,
                    safeMode = safeMode,
                    onSafeChange = { RadarBus.safeMode.value = it },
                    bleEnabled = bleEnabled,
                    onBleChange = { controller.setBleEnabled(it) },
                    backgroundRunning = backgroundRunning,
                    onToggleBackground = toggleBackground
                )
            }

            when (route) {
                "radar" -> RadarScreen(
                    wifi = wifi,
                    ble = ble,
                    safeMode = safeMode,
                    modifier = Modifier.fillMaxSize()
                )
                "wifi" -> WifiScreen(
                    devices = wifi,
                    safeMode = safeMode,
                    modifier = Modifier.fillMaxSize()
                )
                "ble" -> BleScreen(
                    devices = ble,
                    safeMode = safeMode,
                    modifier = Modifier.fillMaxSize()
                )
                "detections" -> DetectionsScreen(
                    detections = detections,
                    safeMode = safeMode,
                    modifier = Modifier.fillMaxSize()
                )
                "log" -> LogScreen(
                    events = events,
                    modifier = Modifier.fillMaxSize()
                )
                "timeline" -> TimelineScreen(
                    timeline = timeline,
                    onClear = {
                        database.clearHistory()
                        RadarBus.log("INFO", "Scan history cleared")
                    },
                    modifier = Modifier.fillMaxSize()
                )
                "debrief" -> DebriefScreen(
                    report = debrief,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}

@Composable
private fun PermissionBanner(onRequestPermission: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer
        )
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "Permissions required",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.onErrorContainer
            )
            Text(
                text = "Meyer Radar needs Location and Bluetooth/Nearby Devices permissions to scan.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onErrorContainer
            )
            Button(onClick = onRequestPermission) {
                Text("Grant permissions")
            }
        }
    }
}

@Composable
private fun ControlStrip(
    scanning: Boolean,
    safeMode: Boolean,
    onSafeChange: (Boolean) -> Unit,
    bleEnabled: Boolean,
    onBleChange: (Boolean) -> Unit,
    backgroundRunning: Boolean,
    onToggleBackground: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("SAFE", style = MaterialTheme.typography.bodySmall)
            Switch(checked = safeMode, onCheckedChange = onSafeChange)
            Spacer(Modifier.width(10.dp))
            Text("BLE", style = MaterialTheme.typography.bodySmall)
            Switch(checked = bleEnabled, onCheckedChange = onBleChange)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onToggleBackground) {
                Text(
                    text = when {
                        backgroundRunning -> "Stop background"
                        scanning -> "Background"
                        else -> "Start"
                    }
                )
            }
        }
    }
}
