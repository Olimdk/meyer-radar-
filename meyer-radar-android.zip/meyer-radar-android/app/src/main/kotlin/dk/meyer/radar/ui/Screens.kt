package dk.meyer.radar.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dk.meyer.radar.data.BleDevice
import dk.meyer.radar.data.DebriefReport
import dk.meyer.radar.data.Detection
import dk.meyer.radar.data.LogEvent
import dk.meyer.radar.data.TimelineEntry
import dk.meyer.radar.data.WifiDevice
import dk.meyer.radar.data.formatTime
import dk.meyer.radar.data.maskMac
import dk.meyer.radar.data.securityLabel
import java.util.Locale

@Composable
fun WifiScreen(
    devices: List<WifiDevice>,
    safeMode: Boolean,
    modifier: Modifier = Modifier
) {
    if (devices.isEmpty()) {
        EmptyState(
            title = "No Wi-Fi networks",
            message = "Ensure Wi-Fi and location permissions are enabled.",
            modifier = modifier
        )
        return
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(devices, key = { it.bssid.ifBlank { it.ssid + it.timestamp } }) { device ->
            WifiCard(device = device, safeMode = safeMode)
        }
    }
}

@Composable
private fun WifiCard(device: WifiDevice, safeMode: Boolean) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = device.ssid.ifBlank { "Hidden network" },
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                RiskBadge(device.riskScore, device.riskLabel)
            }

            InfoRow("BSSID", if (safeMode) maskMac(device.bssid) else device.bssid)
            InfoRow("Signal", "${device.rssi} dBm")
            InfoRow("Frequency", "${device.frequency} MHz")
            InfoRow("Security", securityLabel(device.capabilities))
            InfoRow("Distance", "≈ %.1f m".format(Locale.US, device.distanceMeters))

            if (device.detections.isNotEmpty()) {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "Rule matches",
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
                device.detections.take(3).forEach { detection ->
                    DetectionLine(detection)
                }
            }
        }
    }
}

@Composable
fun BleScreen(
    devices: List<BleDevice>,
    safeMode: Boolean,
    modifier: Modifier = Modifier
) {
    if (devices.isEmpty()) {
        EmptyState(
            title = "No BLE devices",
            message = "Enable Bluetooth and grant Nearby Devices permission.",
            modifier = modifier
        )
        return
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(devices, key = { it.address.ifBlank { it.name + it.timestamp } }) { device ->
            BleCard(device = device, safeMode = safeMode)
        }
    }
}

@Composable
private fun BleCard(device: BleDevice, safeMode: Boolean) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = device.name.ifBlank { "Unnamed BLE device" },
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                RiskBadge(device.riskScore, device.riskLabel)
            }

            InfoRow("Address", if (safeMode) maskMac(device.address) else device.address)
            InfoRow("Signal", "${device.rssi} dBm")
            InfoRow("Distance", "≈ %.1f m".format(Locale.US, device.distanceMeters))
            InfoRow("Service UUIDs", device.serviceUuids.size.toString())
            InfoRow("Manufacturer IDs", device.manufacturerData.size.toString())

            if (device.detections.isNotEmpty()) {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "Rule matches",
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold
                )
                device.detections.take(3).forEach { detection ->
                    DetectionLine(detection)
                }
            }
        }
    }
}

@Composable
fun DetectionsScreen(
    detections: List<Detection>,
    safeMode: Boolean,
    modifier: Modifier = Modifier
) {
    if (detections.isEmpty()) {
        EmptyState(
            title = "No detections",
            message = "Rule matches and possible matches will appear here.",
            modifier = modifier
        )
        return
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(detections, key = {
            it.ruleId + it.identifier + it.matchedField + it.matchedValue
        }) { detection ->
            DetectionCard(detection = detection, safeMode = safeMode)
        }
    }
}

@Composable
private fun DetectionCard(detection: Detection, safeMode: Boolean) {
    val identifierFields = setOf("bssid", "address", "mac", "identifier")
    val observedValue =
        if (safeMode && detection.matchedField.lowercase() in identifierFields) {
            maskMac(detection.matchedValue)
        } else {
            detection.matchedValue
        }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Text(
                text = detection.label,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            InfoRow("Category", detection.category)
            InfoRow("Country", detection.country)
            InfoRow("Confidence", detection.confidence.uppercase())
            InfoRow("Source", detection.source.uppercase())
            InfoRow("Matched field", detection.matchedField)
            InfoRow("Observed", observedValue)
            InfoRow("Device", detection.deviceName.ifBlank { "Unknown" })
            InfoRow(
                "Identifier",
                if (safeMode) maskMac(detection.identifier)
                else detection.identifier.ifBlank { "—" }
            )
            if (detection.notes.isNotBlank()) {
                Text(
                    text = detection.notes,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun DetectionLine(detection: Detection) {
    Text(
        text = "• ${detection.label} (${detection.country}, ${detection.confidence})",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
fun LogScreen(events: List<LogEvent>, modifier: Modifier = Modifier) {
    if (events.isEmpty()) {
        EmptyState(
            title = "No events",
            message = "Scanner and application events will appear here.",
            modifier = modifier
        )
        return
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        itemsIndexed(events) { _, event ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = event.level,
                    color = eventColor(event.level),
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = event.message,
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.bodySmall
                )
                Text(
                    text = formatTime(event.timestamp).takeLast(8),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun TimelineScreen(
    timeline: List<TimelineEntry>,
    onClear: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxSize().padding(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Intel Timeline",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            TextButton(onClick = onClear) {
                Text("Clear")
            }
        }

        Spacer(Modifier.height(8.dp))

        if (timeline.isEmpty()) {
            EmptyState(
                title = "No history",
                message = "Scans will be logged while the application is scanning.",
                modifier = Modifier.fillMaxSize()
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(timeline, key = { it.timestamp.toString() + it.scanType }) { entry ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = formatTime(entry.timestamp),
                                    style = MaterialTheme.typography.bodySmall
                                )
                                Text(
                                    text = entry.scanType.uppercase(),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Targets: ${entry.networkCount}")
                                Text(
                                    text = "Top: ${entry.topThreat}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DebriefScreen(report: DebriefReport?, modifier: Modifier = Modifier) {
    if (report == null) {
        EmptyState(
            title = "No debrief available",
            message = "No scan history has been collected yet.",
            modifier = modifier
        )
        return
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            DebriefSection(title = "Summary") {
                InfoRow("Generated", report.generatedAt)
                InfoRow("Scans", report.totalScans.toString())
                InfoRow("Unique BSSIDs", report.uniqueBssids.toString())
                InfoRow(
                    "Average density",
                    "%.1f networks/scan".format(Locale.US, report.averageDensity)
                )
                InfoRow("Threat level", report.threatLevel)
            }
        }
        item {
            DebriefSection(title = "Frequency bands") {
                if (report.bands.isEmpty()) Text("No Wi-Fi history")
                else report.bands.forEach { (band, count) -> InfoRow(band, count.toString()) }
            }
        }
        item {
            DebriefSection(title = "Security") {
                if (report.security.isEmpty()) Text("No Wi-Fi history")
                else report.security.forEach { (type, count) -> InfoRow(type, count.toString()) }
            }
        }
        item {
            DebriefSection(title = "Open networks") {
                if (report.openNetworks.isEmpty()) Text("None observed")
                else report.openNetworks.forEach { network -> Text("• $network") }
            }
        }
        item {
            DebriefSection(title = "High-risk targets") {
                if (report.highRisk.isEmpty()) Text("None observed")
                else report.highRisk.forEach { target -> Text("• $target") }
            }
        }
        item {
            DebriefSection(title = "Recommendations") {
                report.recommendations.forEach { recommendation -> Text("• $recommendation") }
            }
        }
    }
}

@Composable
private fun DebriefSection(
    title: String,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            content()
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value.ifBlank { "—" },
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun RiskBadge(score: Int, label: String) {
    Text(
        text = "$score/10 $label",
        color = riskColor(score),
        style = MaterialTheme.typography.bodySmall,
        fontWeight = FontWeight.Bold
    )
}

@Composable
private fun EmptyState(
    title: String,
    message: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

private fun riskColor(score: Int): Color = when {
    score >= 6 -> Color(0xFFFF3B3B)
    score >= 3 -> Color(0xFFF5A623)
    score >= 1 -> Color(0xFF00C8FF)
    else -> Color(0xFF39FF14)
}

private fun eventColor(level: String): Color = when (level.uppercase()) {
    "ERROR" -> Color(0xFFFF3B3B)
    "WARN" -> Color(0xFFF5A623)
    else -> Color(0xFF00C8FF)
}
