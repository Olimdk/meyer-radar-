package dk.meyer.radar.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val RadarColors = darkColorScheme(
    primary = Color(0xFF00C8FF),
    secondary = Color(0xFF39FF14),
    tertiary = Color(0xFFF5A623),
    error = Color(0xFFFF3B3B),
    background = Color(0xFF090C10),
    surface = Color(0xFF10151B),
    surfaceVariant = Color(0xFF1A222B),
    onPrimary = Color.Black,
    onSecondary = Color.Black,
    onBackground = Color(0xFFE7F5FF),
    onSurface = Color(0xFFE7F5FF),
    onSurfaceVariant = Color(0xFFB8C7D3)
)

@Composable
fun MeyerRadarTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = RadarColors,
        content = content
    )
}
