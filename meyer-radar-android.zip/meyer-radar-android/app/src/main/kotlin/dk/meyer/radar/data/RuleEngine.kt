package dk.meyer.radar.data

import android.content.Context
import dk.meyer.radar.R
import org.json.JSONObject
import java.io.File
import java.util.Locale

class RuleEngine(private val context: Context) {

    private val rulesFile: File = File(context.filesDir, "detections/rules.json")
    private var rules: List<DetectionRule> = emptyList()
    private var lastModified: Long = 0L
    private var missingReported = false

    fun ensureDefaultRules() {
        rulesFile.parentFile?.mkdirs()
        if (!rulesFile.exists()) {
            context.resources.openRawResource(R.raw.rules).use { input ->
                rulesFile.outputStream().use { output -> input.copyTo(output) }
            }
        }
    }

    fun reload(): Pair<Int, List<String>> {
        ensureDefaultRules()
        val loaded = mutableListOf<DetectionRule>()
        val errors = mutableListOf<String>()

        try {
            val root = JSONObject(rulesFile.readText())
            val array = root.optJSONArray("rules")
            if (array == null) {
                RadarBus.log("ERROR", "rules.json must contain a rules array")
                return rules.size to errors
            }

            for (index in 0 until array.length()) {
                val item = array.optJSONObject(index)
                if (item == null) {
                    errors += "Rule ${index + 1}: expected an object"
                    continue
                }
                val valid = validateRule(item, index + 1)
                if (valid != null) {
                    errors += valid
                    continue
                }

                loaded += DetectionRule(
                    ruleId = item.optString("rule_id"),
                    label = item.optString("label"),
                    category = item.optString("category"),
                    country = item.optString("country", "ANY"),
                    confidence = item.optString("confidence", "low").lowercase(Locale.ROOT),
                    matchType = item.optString("match_type"),
                    matchValue = item.optString("match_value"),
                    notes = item.optString("notes"),
                    enabled = item.optBoolean("enabled", true)
                )
            }

            rules = loaded
            lastModified = rulesFile.lastModified()
            missingReported = false
            RadarBus.rulesVersion.value += 1
        } catch (exception: Exception) {
            errors += "Rule load failed: ${exception.message}"
        }

        errors.forEach { RadarBus.log("ERROR", it) }
        return rules.size to errors
    }

    fun reloadIfChanged(): Boolean {
        if (!rulesFile.exists()) {
            if (!missingReported) {
                missingReported = true
                RadarBus.log("WARN", "rules.json disappeared; using previous rules")
            }
            return false
        }
        val modified = rulesFile.lastModified()
        if (modified == lastModified && rules.isNotEmpty()) return false
        val result = reload()
        RadarBus.log("INFO", "Loaded ${result.first} detection rule(s)")
        return true
    }

    private fun validateRule(rule: JSONObject, number: Int): String? {
        val id = rule.optString("rule_id", "unknown")
        val required = listOf(
            "rule_id", "label", "category", "country", "confidence",
            "match_type", "match_value", "notes"
        )
        val missing = required.filter { !rule.has(it) || rule.optString(it).isBlank() }
        if (missing.isNotEmpty()) return "Rule $number ($id): missing ${missing.joinToString()}"

        val matchType = rule.optString("match_type")
        if (matchType !in setOf(
                "ssid", "ssid_regex", "mac_prefix", "ble_name", "ble_name_regex",
                "vendor", "service_uuid", "manufacturer_data"
            )
        ) return "Rule $number ($id): unsupported match_type $matchType"

        val confidence = rule.optString("confidence").lowercase(Locale.ROOT)
        if (confidence !in setOf("low", "medium", "high")) {
            return "Rule $number ($id): confidence must be low, medium, or high"
        }

        if (matchType.endsWith("_regex")) {
            try {
                Regex(rule.optString("match_value"))
            } catch (exception: Exception) {
                return "Rule $number ($id): invalid regex (${exception.message})"
            }
        }
        return null
    }

    fun evaluateWifi(device: WifiDevice): List<Detection> = evaluate(
        source = "wifi",
        name = device.ssid,
        identifier = device.bssid,
        vendor = "",
        serviceUuids = emptyList(),
        manufacturerData = emptyMap(),
        rssi = device.rssi,
        timestamp = device.timestamp
    )

    fun evaluateBle(device: BleDevice): List<Detection> = evaluate(
        source = "ble",
        name = device.name,
        identifier = device.address,
        vendor = device.vendor,
        serviceUuids = device.serviceUuids,
        manufacturerData = device.manufacturerData,
        rssi = device.rssi,
        timestamp = device.timestamp
    )

    private fun evaluate(
        source: String,
        name: String,
        identifier: String,
        vendor: String,
        serviceUuids: List<String>,
        manufacturerData: Map<Int, String>,
        rssi: Int,
        timestamp: Long
    ): List<Detection> {
        val matches = mutableListOf<Detection>()

        for (rule in rules) {
            if (!rule.enabled) continue
            var matched = false
            var matchedField = ""
            var observedValue = ""

            when (rule.matchType) {
                "ssid" -> {
                    matchedField = "ssid"
                    observedValue = name
                    matched = name.equals(rule.matchValue, ignoreCase = true)
                }
                "ssid_regex" -> {
                    matchedField = "ssid"
                    observedValue = name
                    matched = runCatching { Regex(rule.matchValue).containsMatchIn(name) }.getOrDefault(false)
                }
                "mac_prefix" -> {
                    matchedField = if (source == "wifi") "bssid" else "address"
                    observedValue = identifier
                    val mac = normalizeHex(identifier)
                    val prefix = normalizeHex(rule.matchValue)
                    matched = mac.isNotEmpty() && prefix.isNotEmpty() && mac.startsWith(prefix)
                }
                "ble_name" -> {
                    matchedField = "name"
                    observedValue = name
                    matched = name.equals(rule.matchValue, ignoreCase = true)
                }
                "ble_name_regex" -> {
                    matchedField = "name"
                    observedValue = name
                    matched = runCatching { Regex(rule.matchValue).containsMatchIn(name) }.getOrDefault(false)
                }
                "vendor" -> {
                    matchedField = "vendor"
                    observedValue = vendor
                    matched = vendor.equals(rule.matchValue, ignoreCase = true)
                }
                "service_uuid" -> {
                    matchedField = "service_uuid"
                    val wanted = normalizeHex(rule.matchValue)
                    val found = serviceUuids.firstOrNull { normalizeHex(it) == wanted }
                    if (found != null) {
                        observedValue = found
                        matched = true
                    }
                }
                "manufacturer_data" -> {
                    matchedField = "manufacturer_data"
                    val needle = normalizeHex(rule.matchValue)
                    val entry = manufacturerData.entries.firstOrNull { (companyId, payload) ->
                        val company = companyId.toString(16).padStart(4, '0')
                        normalizeHex(company) == needle || normalizeHex(payload).contains(needle)
                    }
                    if (entry != null) {
                        observedValue = "${entry.key.toString(16).padStart(4, '0')}:${entry.value}"
                        matched = true
                    }
                }
            }

            if (matched) {
                matches += Detection(
                    timestamp = timestamp,
                    source = source,
                    ruleId = rule.ruleId,
                    label = if (rule.confidence == "high") rule.label else "Possible match: ${rule.label}",
                    category = rule.category,
                    country = rule.country,
                    confidence = rule.confidence,
                    matchType = rule.matchType,
                    matchedField = matchedField,
                    matchedValue = observedValue,
                    ruleMatchValue = rule.matchValue,
                    notes = rule.notes,
                    deviceName = name,
                    identifier = identifier,
                    rssi = rssi
                )
            }
        }
        return matches
    }

    private fun normalizeHex(value: String): String =
        value.lowercase(Locale.ROOT).filter { it in '0'..'9' || it in 'a'..'f' }

    fun rulesFilePath(): String = rulesFile.absolutePath
}
