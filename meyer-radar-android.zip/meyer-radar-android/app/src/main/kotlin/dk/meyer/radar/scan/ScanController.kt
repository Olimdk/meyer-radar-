package dk.meyer.radar.scan

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Build
import androidx.core.content.ContextCompat
import dk.meyer.radar.data.BleDevice
import dk.meyer.radar.data.MeyerDatabase
import dk.meyer.radar.data.RadarBus
import dk.meyer.radar.data.RuleEngine
import dk.meyer.radar.data.WifiDevice
import dk.meyer.radar.data.bleRisk
import dk.meyer.radar.data.estimatedDistance
import dk.meyer.radar.data.wifiRisk
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.util.concurrent.ConcurrentHashMap

class ScanController(private val context: Context) {

    companion object {
        val requiredPermissions: Array<String>
            get() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
                )
            } else {
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
            }

        fun hasScanPermissions(context: Context): Boolean =
            requiredPermissions.all {
                ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
            }

        fun hasBluetoothScanPermission(context: Context): Boolean =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.BLUETOOTH_SCAN
                ) == PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
    }

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
    private val bluetoothManager = context.applicationContext.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val database = MeyerDatabase.get(context)
    private val ruleEngine = RuleEngine(context)
    private val bleResults = ConcurrentHashMap<String, BleDevice>()
    private var wifiJob: Job? = null
    private var bleJob: Job? = null
    private var bleScanner: android.bluetooth.le.BluetoothLeScanner? = null
    private var started = false

    private val bleCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            if (!RadarBus.bleEnabled.value) return
            val record = result.scanRecord ?: return
            val manufacturerData = mutableMapOf<Int, String>()
            val sparseData = record.manufacturerSpecificData
            if (sparseData != null) {
                for (index in 0 until sparseData.size()) {
                    val key = sparseData.keyAt(index)
                    val bytes = sparseData.valueAt(index) ?: continue
                    manufacturerData[key] = bytes.joinToString("") { byte ->
                        "%02x".format(byte.toInt() and 0xff)
                    }
                }
            }
            val rssi = result.rssi
            val (score, label) = bleRisk(record.deviceName.orEmpty(), rssi)
            bleResults[result.device.address] = BleDevice(
                name = record.deviceName.orEmpty(),
                address = result.device.address.orEmpty(),
                rssi = rssi,
                serviceUuids = record.serviceUuids?.map { it.uuid.toString() }.orEmpty(),
                manufacturerData = manufacturerData,
                vendor = "",
                distanceMeters = estimatedDistance(rssi, isBle = true),
                riskScore = score,
                riskLabel = label,
                timestamp = System.currentTimeMillis()
            )
        }

        override fun onScanFailed(errorCode: Int) {
            RadarBus.log("ERROR", "BLE scan failed with code $errorCode")
        }
    }

    fun start() {
        if (started) return
        if (!hasScanPermissions(context)) {
            RadarBus.log("ERROR", "Location and Bluetooth permissions are required")
            return
        }
        if (wifiManager == null) RadarBus.log("ERROR", "Wi-Fi service is unavailable")
        ruleEngine.reloadIfChanged()
        started = true
        RadarBus.scanning.value = true
        RadarBus.log("INFO", "Scan controller started")

        wifiJob = appScope.launch { wifiLoop() }
        if (RadarBus.bleEnabled.value) {
            startBleScanner()
            bleJob = appScope.launch { bleFlushLoop() }
        }
    }

    fun stop() {
        if (!started) return
        started = false
        wifiJob?.cancel()
        bleJob?.cancel()
        wifiJob = null
        bleJob = null
        stopBleScanner()
        appScope.coroutineContext.cancelChildren()
        RadarBus.scanning.value = false
        RadarBus.log("INFO", "Scan controller stopped")
    }

    fun close() {
        stop()
    }

    fun setBleEnabled(enabled: Boolean) {
        RadarBus.bleEnabled.value = enabled
        if (!started) return
        if (enabled) {
            startBleScanner()
            if (bleJob == null) bleJob = appScope.launch { bleFlushLoop() }
        } else {
            bleJob?.cancel()
            bleJob = null
            stopBleScanner()
            bleResults.clear()
            RadarBus.ble.value = emptyList()
        }
    }

    private suspend fun wifiLoop() {
        while (appScope.isActive) {
            val cycleStarted = System.currentTimeMillis()
            try {
                ruleEngine.reloadIfChanged()
                @Suppress("DEPRECATION")
                val scanStarted = wifiManager?.startScan() == true
                if (!scanStarted) {
                    RadarBus.log("WARN", "Wi-Fi scan request was throttled or failed")
                }
                delay(800)
                updateWifiResults()
            } catch (security: SecurityException) {
                RadarBus.log("ERROR", "Wi-Fi permission error: ${security.message}")
            } catch (exception: Exception) {
                RadarBus.log("ERROR", "Wi-Fi scan error: ${exception.message}")
            }

            val elapsed = System.currentTimeMillis() - cycleStarted
            delay((3000L - elapsed).coerceAtLeast(250L))
        }
    }

    @SuppressLint("MissingPermission")
    private fun updateWifiResults() {
        val results = wifiManager?.scanResults ?: emptyList()
        val now = System.currentTimeMillis()
        val devices = results.map { result ->
            val capabilities = result.capabilities.orEmpty()
            val (score, label) = wifiRisk(capabilities, result.SSID.orEmpty(), result.level)
            WifiDevice(
                ssid = result.SSID.orEmpty(),
                bssid = result.BSSID.orEmpty(),
                rssi = result.level,
                frequency = result.frequency,
                capabilities = capabilities,
                distanceMeters = estimatedDistance(result.level, result.frequency),
                riskScore = score,
                riskLabel = label,
                timestamp = now
            )
        }.sortedByDescending { it.rssi }.map { device ->
            val detections = ruleEngine.evaluateWifi(device)
            detections.forEach(database::insertDetection)
            RadarBus.addDetections(detections)
            device.copy(detections = detections)
        }

        RadarBus.wifi.value = devices
        if (devices.isNotEmpty()) {
            database.insertScan("wifi", JSONArray(devices.map { it.toJson() }))
        }
    }

    @SuppressLint("MissingPermission")
    private fun startBleScanner() {
        if (!hasBluetoothScanPermission(context)) {
            RadarBus.log("ERROR", "Bluetooth scan permission is missing")
            return
        }
        val adapter = bluetoothManager?.adapter
        if (adapter == null || !adapter.isEnabled) {
            RadarBus.log("WARN", "Bluetooth is disabled")
            return
        }
        try {
            val scanner = adapter.bluetoothLeScanner ?: return
            val settings = ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                .setReportDelay(0)
                .build()
            scanner.startScan(null, settings, bleCallback)
            bleScanner = scanner
            RadarBus.log("INFO", "BLE scanning started")
        } catch (security: SecurityException) {
            RadarBus.log("ERROR", "BLE permission error: ${security.message}")
        } catch (exception: Exception) {
            RadarBus.log("ERROR", "BLE scan start failed: ${exception.message}")
        }
    }

    private fun stopBleScanner() {
        try {
            bleScanner?.stopScan(bleCallback)
        } catch (ignored: Exception) {
            // Stopping an already stopped scanner is harmless.
        }
        bleScanner = null
    }

    private suspend fun bleFlushLoop() {
        while (appScope.isActive) {
            try {
                ruleEngine.reloadIfChanged()
                val now = System.currentTimeMillis()
                val devices = bleResults.values.map { it.copy(timestamp = now) }
                    .sortedByDescending { it.rssi }
                    .map { device ->
                        val detections = ruleEngine.evaluateBle(device)
                        detections.forEach(database::insertDetection)
                        RadarBus.addDetections(detections)
                        device.copy(detections = detections)
                    }
                RadarBus.ble.value = devices
                if (devices.isNotEmpty()) {
                    database.insertScan("ble", JSONArray(devices.map { it.toJson() }))
                }
            } catch (exception: Exception) {
                RadarBus.log("ERROR", "BLE processing error: ${exception.message}")
            }
            delay(1000)
        }
    }
}
