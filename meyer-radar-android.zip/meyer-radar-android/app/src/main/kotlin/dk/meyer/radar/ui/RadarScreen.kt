package dk.meyer.radar.ui

import android.graphics.Paint as AndroidPaint
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dk.meyer.radar.data.BleDevice
import dk.meyer.radar.data.WifiDevice
import dk.meyer.radar.data.maskMac
import java.util.Locale
import java.util.zip.CRC32
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

private data class RadarTarget(
    val key: String,
    val label: String,
    val identifier: String,
    val source: String,
    val distance: Double,
    val bearing: Float,
    val rssi: Int,
    val riskScore: Int,
    val riskLabel: String
)

private fun riskColor(score: Int): Color = when {
    score >= 6 -> Color(0xFFFF3B3B)
    score >= 3 -> Color(0xFFF5A623)
    score >= 1 -> Color(0xFF00C8FF)
    else -> Color(0xFF39FF14)
}

@Composable
fun RadarScreen(
    wifi: List<WifiDevice>,
    ble: List<BleDevice>,
    safeMode: Boolean,
    modifier: Modifier = Modifier
) {
    val targets = remember(wifi, ble) {
        wifi.map { device ->
            val key = "wifi:${device.bssid.ifBlank { device.ssid }}"
            RadarTarget(
                key = key,
                label = device.ssid.ifBlank { "Hidden Wi-Fi" },
                identifier = device.bssid,
                source = "Wi-Fi",
                distance = device.distanceMeters,
                bearing = stableBearing(key),
                rssi = device.rssi,
                riskScore = device.riskScore,
                riskLabel = device.riskLabel
            )
        } + ble.map { device ->
            val key = "ble:${device.address.ifBlank { device.name }}"
            RadarTarget(
                key = key,
                label = device.name.ifBlank { "Unnamed BLE" },
                identifier = device.address,
                source = "BLE",
                distance = device.distanceMeters,
                bearing = stableBearing(key),
                rssi = device.rssi,
                riskScore = device.riskScore,
                riskLabel = device.riskLabel
            )
        }
    }
    var selectedKey by remember { mutableStateOf<String?>(null) }
    var sweep by remember { mutableFloatStateOf(0f) }
    var canvasSize by remember { mutableStateOf(Size.Zero) }
    var canvasTopLeft by remember { mutableStateOf(Offset.Zero) }

    LaunchedEffect(Unit) {
        var lastFrame = 0L
        while (true) {
            withFrameMillis { frame ->
                val delta = if (lastFrame == 0L) 16L else frame - lastFrame
                lastFrame = frame
                sweep = (sweep + delta * 0.08f) % 360f
            }
        }
    }

    val selected = targets.firstOrNull { it.key == selectedKey }
        ?: targets.minByOrNull { it.distance }

    Column(modifier = modifier.fillMaxSize().padding(12.dp)) {
        Text(
            text = "LIVE RELATIVE RADAR",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = "Rings: 25m · 50m · 75m · 100m+  |  Tap a target",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(8.dp))

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .pointerInput(targets, canvasSize) {
                    detectTapGestures { tap ->
                        if (canvasSize == Size.Zero) return@detectTapGestures
                        val local = tap
                        val nearest = targets.minByOrNull { target ->
                            val position = targetOffset(target, canvasSize)
                            val dx = position.x - local.x
                            val dy = position.y - local.y
                            sqrt(dx * dx + dy * dy)
                        }
                        if (nearest != null) {
                            val position = targetOffset(nearest, canvasSize)
                            val dx = position.x - local.x
                            val dy = position.y - local.y
                            if (sqrt(dx * dx + dy * dy) < 48f) selectedKey = nearest.key
                        }
                    }
                }
        ) {
            val textPaint = remember {
                AndroidPaint().apply {
                    color = android.graphics.Color.WHITE
                    textSize = 10f
                    isAntiAlias = true
                    isFakeBoldText = false
                }
            }

            Canvas(modifier = Modifier.fillMaxSize()) {
                canvasSize = size
                canvasTopLeft = Offset.Zero
                val center = Offset(size.width / 2f, size.height / 2f)
                val radius = min(size.width, size.height) / 2f - 14f
                if (radius <= 10f) return@Canvas

                val ringColor = Color(0xFF00C8FF).copy(alpha = 0.22f)
                listOf(0.25f, 0.5f, 0.75f, 1f).forEach { factor ->
                    drawCircle(
                        color = ringColor,
                        radius = radius * factor,
                        center = center,
                        style = Stroke(width = 1f)
                    )
                }
                drawLine(ringColor, Offset(center.x - radius, center.y), Offset(center.x + radius, center.y), strokeWidth = 1f)
                drawLine(ringColor, Offset(center.x, center.y - radius), Offset(center.x, center.y + radius), strokeWidth = 1f)

                drawArc(
                    color = Color(0xFF00C8FF).copy(alpha = 0.10f),
                    startAngle = sweep - 75f,
                    sweepAngle = 75f,
                    useCenter = true,
                    topLeft = Offset(center.x - radius, center.y - radius),
                    size = Size(radius * 2f, radius * 2f)
                )

                val sweepRadians = Math.toRadians(sweep.toDouble())
                drawLine(
                    color = Color(0xFF00C8FF),
                    start = center,
                    end = Offset(
                        center.x + (cos(sweepRadians) * radius).toFloat(),
                        center.y + (sin(sweepRadians) * radius).toFloat()
                    ),
                    strokeWidth = 3f
                )

                targets.forEach { target ->
                    val position = targetOffset(target, size)
                    val color = riskColor(target.riskScore)
                    drawCircle(color = color, radius = 7f, center = position)
                    if (target.riskScore >= 6) {
                        drawCircle(
                            color = color.copy(alpha = 0.35f),
                            radius = 13f,
                            center = position,
                            style = Stroke(width = 2f)
                        )
                    }
                    textPaint.color = android.graphics.Color.WHITE
                    drawContext.canvas.nativeCanvas.drawText(
                        target.label.take(14),
                        position.x + 10f,
                        position.y - 8f,
                        textPaint
                    )
                }

                drawCircle(Color(0xFF00C8FF), radius = 5f, center = center)
                drawCircle(Color.White, radius = 2f, center = center)
            }
        }

        Spacer(Modifier.height(8.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                if (selected == null) {
                    Text("No Wi-Fi or BLE targets currently visible", fontWeight = FontWeight.Bold)
                    Text("Enable Wi-Fi, Bluetooth, and the required permissions.")
                } else {
                    Text(
                        text = selected.label.ifBlank { "Unnamed target" },
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = riskColor(selected.riskScore)
                    )
                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text(selected.source, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("≈ %.1f m".format(Locale.US, selected.distance))
                    }
                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("RSSI: ${selected.rssi} dBm", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("Risk: ${selected.riskScore}/10 ${selected.riskLabel}")
                    }
                    Text(
                        text = "ID: ${if (safeMode) maskMac(selected.identifier) else selected.identifier.ifBlank { "—" }}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Position is relative distance only; it is not a compass bearing.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

private fun stableBearing(key: String): Float {
    val checksum = CRC32()
    checksum.update(key.toByteArray())
    return (checksum.value % 360L).toFloat()
}

private fun targetOffset(target: RadarTarget, size: Size): Offset {
    val center = Offset(size.width / 2f, size.height / 2f)
    val radius = min(size.width, size.height) / 2f - 14f
    val fraction = (target.distance.coerceIn(0.0, 100.0) / 100.0).toFloat()
    val radians = Math.toRadians(target.bearing.toDouble())
    return Offset(
        x = center.x + (cos(radians) * radius * fraction).toFloat(),
        y = center.y + (sin(radians) * radius * fraction).toFloat()
    )
}
